$(function () {
    
	 //图片放大工具
    imageMagnify("icon");
});

var vm = new Vue({
	el:'#rrapp',
	data:{
		q:{
			activityName: null
		},
		showList: true,
		title:null,
		activity : {
			languageList:[]
		},
		languageList:[],
		tableData:[]
	},
	methods: {
		query: function () {
			
		},
		saveOrUpdate: function () {
			window.location.href="banner.html"
		},
		getLanguageList: function(){
			$.ajax({
				  type: "GET",
				  url: "../json/language.json",
				  dataType: "json",
				  success : function(r){
					  vm.languageList =r;
					  console.info(r);
				  }
			});
		},
		cancel : function(){
			
		},
		getDetailInfo : function(){
			var _obj = {};
			_obj.rewardsName = "一等奖";
			_obj.rank = "1";
			_obj.quantity = "3";
			_obj.score = "20";
			_obj.empiricalValue = "100";
			_obj.quantity = "待定";
			_obj.awardsMethod = "-";
			_obj.remark = "-";
			vm.tableData.push(_obj);
			vm.getLanguageList();
		}
	}
});
vm.getDetailInfo();
