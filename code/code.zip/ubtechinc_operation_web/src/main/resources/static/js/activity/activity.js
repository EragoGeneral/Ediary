$(function () {
    $("#jqGrid").jqGrid({
        //url: baseURL + 'sys/user/list',
    	url: '../json/activity.json',
        datatype: "json",
        colModel: [			
			{ label: '活动ID', name: 'activityId', index: "activity_id", width: 45, key: true },
			{ label: '类型', name: 'activityType', width: 75, formatter: function(value, options, row){
				if(value == 1){
					return '图片';
				}else if(value == 2){
					return '视频';
				}else if(value == 3){
					return '程序';
				}else if(value == 4){
					return '机器人';
				}
			 }},
            { label: '简图', name: 'displayImage', width: 75, formatter: function(value, options, row){
				 	return '<img class="icon" style="width:90px;heigt:90px;" src="http://img1.3lian.com/2015/a1/84/d/95.jpg"/>'
			}},
			{ label: '标题', name: 'heading', width: 90 },
			{ label: '开始时间', name: 'startTime', width: 80 },
			{ label: '结束时间', name: 'endTime', width: 90},
			{ label: '评论数', name: 'commentTimes', width: 90},
			{ label: '浏览数', name: 'browseTimes', width: 90},
			{ label: '参与数', name: 'partInTimes', width: 90},
			{ label: '分享数', name: 'shareTimes', width: 90},
			{ label: '操作', name: 'shareTimes', width: 180, formatter: function(value, options, row){
					var opHtml = '<a class="btn btn-info btn-small" onclick="viewDetail()">查看</a>'
						+'<a class="btn btn-danger btn-small" onclick = "edit()" style="margin-left:15px;"> 编辑</a>'
					return opHtml;
			}}
        ],
		viewrecords: true,
        height: 385,
        rowNum: 10,
		rowList : [10,30,50],
        //rownumbers: true, 
        rownumWidth: 25, 
        autowidth:true,
        multiselect: true,
        pager: "#jqGridPager",
        jsonReader : {
            root: "page.list",
            page: "page.currPage",
            total: "page.totalPage",
            records: "page.totalCount"
        },
        prmNames : {
            page:"page", 
            rows:"limit", 
            order: "order"
        },
        gridComplete:function(){
        	//隐藏grid底部滚动条
        	$("#jqGrid").closest(".ui-jqgrid-bdiv").css({ "overflow-x" : "hidden" }); 
        }
    });
    //图片放大工具
    imageMagnify("icon");
    
    $("#act_status li").each(function(data){
    	$(this).click(function(){
    		$("#act_status li").siblings().css({"border-bottom":"0px solid #bbb"});
    		$(this).css({"border-bottom":"3px solid #bbb"});
    	});
    });
    
});

function initUpload(id){
	new AjaxUpload(id, {
        action: baseURL + 'sys/oss/upload?token=' + token,
        name: 'file',
        autoSubmit:true,
        responseType:"json",
        onSubmit:function(file, extension){
            if(vm.config.type == null){
                alert("云存储配置未配置");
                return false;
            }
            if (!(extension && /^(jpg|jpeg|png|gif)$/.test(extension.toLowerCase()))){
                alert('只支持jpg、png、gif格式的图片！');
                return false;
            }
        },
        onComplete : function(file, r){
            if(r.code == 0){
                alert(r.url);
                //vm.reload();
            }else{
                alert(r.msg);
            }
        }
    });
}






var vm = new Vue({
	el:'#rrapp',
	data:{
		q:{
			activityName: null
		},
		showList: true,
		title:null,
		activity : {
			languageList:[]
		},
		config: {},
		languageList:[],
		tableData:[]
	},
	methods: {
		query: function () {
			vm.reload();
		},
		
	    getConfig: function () {
            $.getJSON(baseURL + "sys/oss/config", function(r){
				vm.config = r.config;
            });
        },
		add: function(){
			vm.showList = false;
			vm.title = "新增";
			vm.languageList = [];
			vm.activity = {languageList:[]};
			initUpload('#upload');
			//获取语言信息1
			vm.getLanguageList();
			//时间插件
			//$('#datetimepicker').datetimepicker();
			 $("#datetimepicker").datetimepicker();
			 $("#startTime").datetimepicker();
			 $("#endTime").datetimepicker();
			 //初始化奖品表格
			 vm.addTableTr();
			 //初始化富文本框
			 var E = window.wangEditor
		     var editor = new E('#desc_editor')
		        // 或者 var editor = new E( document.getElementById('#editor') )
		     editor.create();
			 this.getConfig();
		},
        
		update: function () {
			var userId = getSelectedRow();
			if(userId == null){
				return ;
			}
			vm.showList = false;
            vm.title = "修改";
			vm.getUser(userId);
			this.getLanguageList();
			$("#datetimepicker").datetimepicker();
			 $("#startTime").datetimepicker();
			 $("#endTime").datetimepicker();
			 //初始化奖品表格
			 vm.addTableTr();
			 //初始化富文本框
			 var E = window.wangEditor
		     var editor = new E('#desc_editor')
		        // 或者 var editor = new E( document.getElementById('#editor') )
		     editor.create()
		},
		del: function () {
			var userIds = getSelectedRows();
			if(userIds == null){
				return ;
			}
			
			confirm('确定要删除选中的记录？', function(){
				$.ajax({
					type: "POST",
				    url: baseURL + "sys/user/delete",
                    contentType: "application/json",
				    data: JSON.stringify(userIds),
				    success: function(r){
						if(r.code == 0){
							alert('操作成功', function(){
                                vm.reload();
							});
						}else{
							alert(r.msg);
						}
					}
				});
			});
		},
		saveOrUpdate: function () {
			/*var url = vm.user.userId == null ? "sys/user/save" : "sys/user/update";
			$.ajax({
				type: "POST",
			    url: baseURL + url,
                contentType: "application/json",
			    data: JSON.stringify(vm.user),
			    success: function(r){
			    	if(r.code === 0){
						alert('操作成功', function(){
							vm.reload();
						});
					}else{
						alert(r.msg);
					}
				}
			});*/
			window.location.href="banner.html"
		},
		getUser: function(userId){
			$.get(baseURL + "sys/user/info/"+userId, function(r){
				vm.user = r.user;
				vm.user.password = null;
			});
		},
		getLanguageList: function(){
			$.ajax({
				  type: "GET",
				  url: "../json/language.json",
				  dataType: "json",
				  success : function(r){
					  vm.languageList =r;
					  console.info(r);
				  }
			});
		},
		reload: function () {
			vm.showList = true;
			var page = $("#jqGrid").jqGrid('getGridParam','page');
			$("#jqGrid").jqGrid('setGridParam',{ 
                postData:{'username': vm.q.username},
                page:page
            }).trigger("reloadGrid");
		},
		addTableTr : function() {
				var _obj = {};
				_obj.rewardsName = "";
				_obj.rank = "";
				_obj.quantity = "";
				_obj.score = "";
				_obj.empiricalValue = "";
				_obj.quantity = "";
				_obj.awardsMethod = "";
				_obj.remark = "";
				vm.tableData.push(_obj);
		},
		delTableTr : function(event){
			console.info(this.name);
		},
		viewDetail : function(){
			location.href = "activityDetail.html";
		}
	}
});

function viewDetail(){
	location.href = "activityDetail.html";	
}

function edit(){
	vm.update();
}

