
$(function () {
	 //获取获奖作品
	 $("#jqGrid").jqGrid({
	    	url: '../json/works.json',
	        datatype: "json",
	        colModel: [	
					{ label: '图片', name: 'filePath', width: 120, formatter: function(value, options, row){
					 	return '<img style="width:100px;" src="http://img1.3lian.com/2015/a1/84/d/95.jpg"/>'
					}},
					{ label: '标题', name: 'modelName', width: 130 },
					{ label: '上传时间', name: 'modelCreatedTime', width: 120 },
					{ label: '浏览量', name: 'modelCheckNum', width: 70 },
					{ label: '收藏量', name: 'modelCollectNum', width: 70 },
					{ label: '评论量', name: 'modelCommentNum', width: 70 },
					{ label: '分享量', name: 'modelShareNum', width: 70 },
					{ label: '操作',  formatter: function(value, options, row){
						var opHtml = '<a class="btn btn-info btn-small">查看</a>'
									+'<a class="btn btn-danger btn-small" style="margin-left:15px;"> 删除</a>'
						return opHtml;
					}}
	        ],
			viewrecords: true,
	        height: 385,
	        rowNum: 10,
			rowList : [10,30,50],
	       // rownumbers: true, 
	        //rownumWidth: 25, 
	        autowidth:true,
	        multiselect: true,
	        pager: "#jqGridPager",
	        jsonReader : {
	            root: "page.list",
	            page: "page.currPage",
	            total: "page.totalPage",
	            records: "page.totalCount"
	        },
	        prmNames : {
	            page:"page", 
	            rows:"limit", 
	            order: "order"
	        },
	        gridComplete:function(){
	        	//隐藏grid底部滚动条
	        	$("#jqGrid").closest(".ui-jqgrid-bdiv").css({ "overflow-x" : "hidden" }); 
	        }
	    });
});


var vm = new Vue({
	el:'#rrapp',
	data:{
		q:{
			activityName: null
		},
		showList: true,
		title:null,
		activity : {
			languageList:[]
		},
		languageList:[],
		tableData:[]
	},
	methods: {
		query: function () {
			vm.reload();
		},
		add: function(){
			vm.showList = false;
			vm.title = "新增";
			vm.languageList = [];
			vm.activity = {languageList:[]};
			
			//获取语言信息1
			vm.getLanguageList();
			//时间插件
			//$('#datetimepicker').datetimepicker();
			 $("#datetimepicker").datetimepicker();
			 $("#startTime").datetimepicker();
			 $("#endTime").datetimepicker();
			 //初始化奖品表格
			 vm.addTableTr();
			 //初始化富文本框
			 var E = window.wangEditor
		     var editor = new E('#desc_editor')
		        // 或者 var editor = new E( document.getElementById('#editor') )
		     editor.create()
		},
        
		update: function () {
			var userId = getSelectedRow();
			if(userId == null){
				return ;
			}
			vm.showList = false;
            vm.title = "修改";
			vm.getUser(userId);
			this.getLanguageList();
			$("#datetimepicker").datetimepicker();
			 $("#startTime").datetimepicker();
			 $("#endTime").datetimepicker();
			 //初始化奖品表格
			 vm.addTableTr();
			 //初始化富文本框
			 var E = window.wangEditor
		     var editor = new E('#desc_editor')
		        // 或者 var editor = new E( document.getElementById('#editor') )
		     editor.create()
		},
		del: function () {
			var userIds = getSelectedRows();
			if(userIds == null){
				return ;
			}
			
			confirm('确定要删除选中的记录？', function(){
				$.ajax({
					type: "POST",
				    url: baseURL + "sys/user/delete",
                    contentType: "application/json",
				    data: JSON.stringify(userIds),
				    success: function(r){
						if(r.code == 0){
							alert('操作成功', function(){
                                vm.reload();
							});
						}else{
							alert(r.msg);
						}
					}
				});
			});
		},
		saveOrUpdate: function () {
			alert('保存成功！');
			//window.location.href="banner.html"
		},
		getUser: function(userId){
			$.get(baseURL + "sys/user/info/"+userId, function(r){
				vm.user = r.user;
				vm.user.password = null;
			});
		},
		getLanguageList: function(){
			$.ajax({
				  type: "GET",
				  url: "../json/language.json",
				  dataType: "json",
				  success : function(r){
					  vm.languageList =r;
					  console.info(r);
				  }
			});
		},
		reload: function () {
			vm.showList = true;
			var page = $("#jqGrid").jqGrid('getGridParam','page');
			$("#jqGrid").jqGrid('setGridParam',{ 
                postData:{'username': vm.q.username},
                page:page
            }).trigger("reloadGrid");
		},
		selectWorks : function() {
			$("#myModal").modal('show');
			$("#jqGrid").jqGrid('setGridParam',{ 
                postData:{},
                page:page
            }).trigger("reloadGrid");
		}
	}
});