/*
SQLyog Ultimate v12.08 (32 bit)
MySQL - 5.7.13-log : Database - lightmvc
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`lightmvc` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `lightmvc`;

/*Table structure for table `demo` */

DROP TABLE IF EXISTS `demo`;

CREATE TABLE `demo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='DEMO';

/*Data for the table `demo` */

insert  into `demo`(`id`,`name`,`description`) values (1,'name2','desc2');

/*Table structure for table `sys_organization` */

DROP TABLE IF EXISTS `sys_organization`;

CREATE TABLE `sys_organization` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  `code` varchar(64) NOT NULL,
  `icon` varchar(32) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `seq` tinyint(1) NOT NULL DEFAULT '0',
  `createdatetime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='组织机构';

/*Data for the table `sys_organization` */

insert  into `sys_organization`(`id`,`name`,`address`,`code`,`icon`,`pid`,`seq`,`createdatetime`) values (1,'JAVA快速开发框架','地址','01','icon-company',NULL,0,'2014-02-19 01:00:00'),(2,'新部门1','地址1','02','icon-company',1,0,'2016-08-01 13:22:11');

/*Table structure for table `sys_resource` */

DROP TABLE IF EXISTS `sys_resource`;

CREATE TABLE `sys_resource` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `url` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `icon` varchar(32) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `seq` tinyint(1) NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `resourcetype` tinyint(1) NOT NULL DEFAULT '0',
  `createdatetime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=217 DEFAULT CHARSET=utf8 COMMENT='资源';

/*Data for the table `sys_resource` */

insert  into `sys_resource`(`id`,`name`,`url`,`description`,`icon`,`pid`,`seq`,`state`,`resourcetype`,`createdatetime`) values (1,'系统管理','','系统管理','icon-company',NULL,7,0,0,'2014-02-19 01:00:00'),(2,'代码演示','','代码演示','icon-company',NULL,6,0,0,'2014-02-19 01:00:00'),(11,'资源管理','/resource/manager','资源管理','icon-folder',1,1,0,0,'2014-02-19 01:00:00'),(12,'角色管理','/role/manager','角色管理','icon-folder',1,2,0,0,'2014-02-19 01:00:00'),(13,'用户管理','/user/manager','用户管理','icon-folder',1,3,0,0,'2014-02-19 01:00:00'),(14,'部门管理','/organization/manager','部门管理','icon-folder',1,4,0,0,'2014-02-19 01:00:00'),(21,'DEMO管理','/demo/manager','DEMO管理','icon-folder',2,1,0,0,'2014-02-19 01:00:00'),(22,'EASYUI','http://www.jeasyui.com','EASYUI','icon-folder',2,1,0,0,'2014-02-19 01:00:00'),(111,'列表','/resource/treeGrid','资源列表','icon-btn',11,0,0,1,'2014-02-19 01:00:00'),(112,'添加','/resource/add','资源添加','icon-btn',11,0,0,1,'2014-02-19 01:00:00'),(113,'编辑','/resource/edit','资源编辑','icon-btn',11,0,0,1,'2014-02-19 01:00:00'),(114,'删除','/resource/delete','资源删除','icon-btn',11,0,0,1,'2014-02-19 01:00:00'),(121,'列表','/role/dataGrid','角色列表','icon-btn',12,0,0,1,'2014-02-19 01:00:00'),(122,'添加','/role/add','角色添加','icon-btn',12,0,0,1,'2014-02-19 01:00:00'),(123,'编辑','/role/edit','角色编辑','icon-btn',12,0,0,1,'2014-02-19 01:00:00'),(124,'删除','/role/delete','角色删除','icon-btn',12,0,0,1,'2014-02-19 01:00:00'),(125,'授权','/role/grant','角色授权','icon-btn',12,0,0,1,'2014-02-19 01:00:00'),(131,'列表','/user/dataGrid','用户列表','icon-btn',13,0,0,1,'2014-02-19 01:00:00'),(132,'添加','/user/add','用户添加','icon-btn',13,0,0,1,'2014-02-19 01:00:00'),(133,'编辑','/user/edit','用户编辑','icon-btn',13,0,0,1,'2014-02-19 01:00:00'),(134,'删除','/user/delete','用户删除','icon-btn',13,0,0,1,'2014-02-19 01:00:00'),(135,'查看','/user/view','用户查看','icon-btn',13,0,0,1,'2014-02-19 01:00:00'),(141,'列表','/organization/treeGrid','用户列表','icon-btn',14,0,0,1,'2014-02-19 01:00:00'),(142,'添加','/organization/add','部门添加','icon-btn',14,0,0,1,'2014-02-19 01:00:00'),(143,'编辑','/organization/edit','部门编辑','icon-btn',14,0,0,1,'2014-02-19 01:00:00'),(144,'删除','/organization/delete','部门删除','icon-btn',14,0,0,1,'2014-02-19 01:00:00'),(145,'查看','/organization/view','部门查看','icon-btn',14,0,0,1,'2014-02-19 01:00:00'),(211,'列表','/demo/dataGrid','列表','icon-btn',21,0,0,1,'2014-02-19 01:00:00'),(212,'添加','/demo/add',NULL,'icon-btn',21,1,0,1,'2014-02-19 01:00:00'),(213,'编辑','/demo/edit',NULL,'icon-btn',21,3,0,1,'2014-02-19 01:00:00'),(214,'删除','/demo/delete',NULL,'icon-btn',21,2,0,1,'2014-02-19 01:00:00'),(215,'查看','/demo/view',NULL,'icon-btn',21,4,0,1,'2014-02-19 01:00:00'),(216,'测试动作','/demo/test',NULL,'icon-btn',21,5,0,1,'2016-07-26 14:48:12');

/*Table structure for table `sys_role` */

DROP TABLE IF EXISTS `sys_role`;

CREATE TABLE `sys_role` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `seq` tinyint(1) NOT NULL DEFAULT '0',
  `description` varchar(255) DEFAULT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='角色';

/*Data for the table `sys_role` */

insert  into `sys_role`(`id`,`name`,`seq`,`description`,`isdefault`) values (1,'超级管理员',0,'超级管理员，拥有全部权限',0),(2,'销售管理员',0,'',1),(3,'市场管理员',0,'测试数据',1);

/*Table structure for table `sys_role_resource` */

DROP TABLE IF EXISTS `sys_role_resource`;

CREATE TABLE `sys_role_resource` (
  `role_id` smallint(5) NOT NULL,
  `resource_id` smallint(5) NOT NULL,
  PRIMARY KEY (`role_id`,`resource_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='角色资源';

/*Data for the table `sys_role_resource` */

insert  into `sys_role_resource`(`role_id`,`resource_id`) values (1,1),(1,2),(1,11),(1,12),(1,13),(1,14),(1,21),(1,22),(1,111),(1,112),(1,113),(1,114),(1,121),(1,122),(1,123),(1,124),(1,125),(1,131),(1,132),(1,133),(1,134),(1,135),(1,141),(1,142),(1,143),(1,144),(1,145),(1,211),(1,212),(1,213),(1,214),(1,215),(2,1),(2,11),(2,14),(2,21),(2,111),(2,112),(2,141),(2,143),(2,145),(2,211),(2,212),(2,215);

/*Table structure for table `sys_user` */

DROP TABLE IF EXISTS `sys_user`;

CREATE TABLE `sys_user` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `loginname` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `sex` tinyint(1) NOT NULL DEFAULT '0',
  `age` tinyint(1) NOT NULL DEFAULT '0',
  `usertype` tinyint(1) NOT NULL DEFAULT '0',
  `isdefault` tinyint(1) NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `organization_id` int(11) NOT NULL DEFAULT '0',
  `createdatetime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `loginname` (`loginname`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户';

/*Data for the table `sys_user` */

insert  into `sys_user`(`id`,`loginname`,`name`,`password`,`customer_id`,`sex`,`age`,`usertype`,`isdefault`,`state`,`organization_id`,`createdatetime`,`phone`) values (1,'admin','超级管理员','21232f297a57a5a743894a0e4a801fc3',NULL,0,18,0,0,0,1,'2012-06-04 01:00:00',NULL),(2,'sales','销售员1','e10adc3949ba59abbe56e057f20f883e',NULL,0,22,1,0,0,1,'2016-07-21 18:07:29','');

/*Table structure for table `sys_user_role` */

DROP TABLE IF EXISTS `sys_user_role`;

CREATE TABLE `sys_user_role` (
  `user_id` smallint(5) NOT NULL,
  `role_id` smallint(5) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户角色';

/*Data for the table `sys_user_role` */

insert  into `sys_user_role`(`user_id`,`role_id`) values (1,1),(2,2);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
