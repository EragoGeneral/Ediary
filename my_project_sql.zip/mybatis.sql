/*
SQLyog Ultimate v12.08 (32 bit)
MySQL - 5.7.13-log : Database - mybatis
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`mybatis` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `mybatis`;

/*Table structure for table `book` */

DROP TABLE IF EXISTS `book`;

CREATE TABLE `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL,
  `author` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

/*Data for the table `book` */

insert  into `book`(`id`,`name`,`author`) values (1,'物理学的困惑','L·斯莫林'),(3,'精通Nginx','陶利军'),(4,'沟通的艺术','黄素菲'),(5,'天才在左，疯子在右','高铭'),(6,'关键冲突','科里·帕特森等'),(7,'人类思维中最致命的错误','罗伯特·伯顿'),(8,'遇见懂得付出的自己','盖瑞·查普曼'),(9,'黑客与画家','Paul Graham'),(10,'精益创业','〔美〕埃里克·莱斯'),(11,'浪潮之巅','[美] 吴军'),(12,'软件随想录','[美] Joel Spolsky'),(13,'程序员修炼之道','Andrew Hunt&David Thomas'),(14,'重来','〔美〕贾森·弗里德〔丹〕戴维·海涅迈尔·汉森');

/*Table structure for table `class` */

DROP TABLE IF EXISTS `class`;

CREATE TABLE `class` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(20) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `class` */

insert  into `class`(`c_id`,`c_name`,`teacher_id`) values (1,'class_a',1),(2,'class_b',2);

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `link` varchar(256) DEFAULT NULL,
  `desc` varchar(128) DEFAULT NULL,
  `title` varchar(64) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `product` */

insert  into `product`(`id`,`category_id`,`price`,`link`,`desc`,`title`,`description`) values (1,1,100,'http://www.dangdang.com/products/111h.html','可以看看','值得一读',NULL),(2,2,25,'http://www.dangdang.com/products/122h.html','可以看看','一本好书',NULL),(4,3,64,'http://www.dangdang.com/products/653h.html','可以看看','一本好书',NULL);

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `s_id` int(11) NOT NULL AUTO_INCREMENT,
  `s_name` varchar(20) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

/*Data for the table `student` */

insert  into `student`(`s_id`,`s_name`,`class_id`) values (1,'student_A',1),(2,'student_B',1),(3,'student_C',1),(4,'student_D',2),(5,'student_E',2),(6,'student_F',2);

/*Table structure for table `system_menus` */

DROP TABLE IF EXISTS `system_menus`;

CREATE TABLE `system_menus` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `Name` varchar(20) NOT NULL COMMENT '菜单名称',
  `Link` varchar(100) DEFAULT NULL COMMENT '菜单链接',
  `Display_Order` int(11) DEFAULT NULL COMMENT '显示顺序',
  `Parent_ID` int(11) NOT NULL COMMENT '父节点ID',
  `Level` int(11) DEFAULT NULL COMMENT '菜单层级',
  `Type` int(11) DEFAULT NULL COMMENT '资源类型',
  `Path` varchar(50) DEFAULT NULL COMMENT '菜单路径',
  `Is_Deleted` varchar(1) NOT NULL COMMENT '是否有效',
  `Create_By` int(11) DEFAULT NULL COMMENT '创建人',
  `Create_Date` datetime DEFAULT NULL COMMENT '创建时间',
  `Update_By` int(11) DEFAULT NULL COMMENT '最后更新人',
  `Update_Date` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`ID`,`Name`,`Parent_ID`,`Is_Deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `system_menus` */

insert  into `system_menus`(`ID`,`Name`,`Link`,`Display_Order`,`Parent_ID`,`Level`,`Type`,`Path`,`Is_Deleted`,`Create_By`,`Create_Date`,`Update_By`,`Update_Date`) values (1,'系统管理','/System',1,-1,1,NULL,'1','0',1,'2016-07-20 10:50:03',1,'2016-07-20 10:50:08'),(2,'用户管理','user/manage',1,1,2,NULL,'1.2','0',1,'2016-07-20 11:02:16',1,'2016-07-20 11:02:18'),(3,'菜单管理','resources/pages/menu/menus_list.html',3,1,2,NULL,'1.3','1',1,'2016-07-21 14:41:10',1,'2016-07-21 14:41:12'),(4,'供应商管理','/Provider',2,-1,1,NULL,'4','1',1,'2016-07-21 14:42:26',1,'2016-07-21 14:42:28'),(5,'供应商查询','resources/pages/provider/pro_list.html',1,4,2,NULL,'4.5','1',1,'2016-07-21 14:43:43',1,'2016-07-21 14:43:45'),(6,'角色管理','role/manage',2,1,2,NULL,'1.5','0',1,'2016-07-23 16:12:27',1,'2016-07-23 16:12:28'),(7,'资源管理','resource/manage',3,1,2,NULL,'1.7','0',1,'2016-07-26 10:05:38',1,'2016-07-26 10:05:40');

/*Table structure for table `system_users` */

DROP TABLE IF EXISTS `system_users`;

CREATE TABLE `system_users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `Login_Name` varchar(30) NOT NULL,
  `User_Name` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Gender` varchar(1) DEFAULT NULL,
  `Birth` date DEFAULT NULL,
  `Dept_No` int(11) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Mobile` varchar(11) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `Create_By` int(11) DEFAULT NULL,
  `Create_Date` datetime DEFAULT NULL,
  `Update_By` int(11) DEFAULT NULL,
  `Update_Date` datetime DEFAULT NULL,
  `Is_Deleted` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

/*Data for the table `system_users` */

insert  into `system_users`(`ID`,`Login_Name`,`User_Name`,`Password`,`Gender`,`Birth`,`Dept_No`,`Email`,`Mobile`,`Address`,`Create_By`,`Create_Date`,`Update_By`,`Update_Date`,`Is_Deleted`) values (1,'admin','系统管理员','admin','M','1991-01-14',0,'aa@gmail.com','13966201125','广东省深圳市南山区高新南七道',1,'2016-07-20 10:52:15',1,'2016-07-20 16:57:21','0'),(2,'Sales','销售主管','123456','F','1984-02-21',2,'sales@sina.com','17099382771',NULL,1,'2016-07-21 10:27:36',1,'2016-07-21 10:27:38','0'),(5,'HR','人事主管','123456','F','1989-06-30',1,'hr@gmail.com','13655230078',NULL,1,'2016-07-20 17:06:38',1,'2016-07-20 17:06:38','0'),(6,'zhangsan','张三','123456','M','1990-10-21',1,'zs@163.com','18933652201',NULL,1,'2016-07-21 10:23:29',1,'2016-07-21 10:23:26','0'),(7,'Lisi','李四','123456','F','1992-11-10',1,'ls@163.com','15200930092',NULL,1,'2016-07-21 10:24:14',1,'2016-07-21 10:24:17','0'),(8,'wangwu','王五','123456','M','1989-09-21',1,'ww@sohu.com','18300928810',NULL,1,'2016-07-21 10:25:03',1,'2016-07-21 10:25:06','0'),(9,'Support','技术支持','123456','F','1993-02-15',3,'support@qq.com','15109886522',NULL,1,'2016-07-22 16:31:22',1,'2016-07-27 14:40:10','0'),(10,'OP1','秦六合','123456','F','1993-08-03',NULL,NULL,'13789099382',NULL,1,'2016-07-26 14:22:45',1,'2016-07-26 14:24:11','0'),(11,'sale1','销售专员1','123456','F','1994-02-11',NULL,'sales1@sina.com','18966352210',NULL,1,'2016-07-27 14:01:36',1,'2016-07-27 14:02:47','0'),(12,'sale2','销售专员2','123456','F','1990-12-26',NULL,'sales2@gmail.com','17533021156',NULL,1,'2016-07-27 14:16:31',1,'2016-07-27 14:16:44','0'),(13,'off1','行政1','123456','F','1993-04-12',NULL,'off1@sina.com','13400215562',NULL,1,'2016-07-28 09:56:33',1,'2016-07-28 09:56:33','0');

/*Table structure for table `t_permission` */

DROP TABLE IF EXISTS `t_permission`;

CREATE TABLE `t_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionname` varchar(32) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

/*Data for the table `t_permission` */

insert  into `t_permission`(`id`,`permissionname`,`role_id`) values (1,'add',2),(2,'del',1),(3,'update',2),(4,'query',3),(5,'user:query',1),(6,'user:edit',2);

/*Table structure for table `t_role` */

DROP TABLE IF EXISTS `t_role`;

CREATE TABLE `t_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rolename` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `t_role` */

insert  into `t_role`(`id`,`rolename`) values (1,'admin'),(2,'manager'),(3,'normal');

/*Table structure for table `t_user` */

DROP TABLE IF EXISTS `t_user`;

CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `gender` int(1) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `t_user` */

insert  into `t_user`(`id`,`username`,`password`,`gender`,`age`) values (1,'tom','123456',1,25),(2,'jack','123456',1,23),(3,'rose','123456',2,22);

/*Table structure for table `t_user_role` */

DROP TABLE IF EXISTS `t_user_role`;

CREATE TABLE `t_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `t_user_role` */

insert  into `t_user_role`(`id`,`user_id`,`role_id`) values (1,1,1),(2,1,1),(3,2,2),(4,2,2),(5,3,3);

/*Table structure for table `teacher` */

DROP TABLE IF EXISTS `teacher`;

CREATE TABLE `teacher` (
  `t_id` int(11) NOT NULL AUTO_INCREMENT,
  `t_name` varchar(20) DEFAULT NULL,
  `t_city` varchar(20) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`t_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `teacher` */

insert  into `teacher`(`t_id`,`t_name`,`t_city`,`create_time`) values (1,'teacher1','Beijing','2017-07-22 10:17:06'),(2,'teacher2','London','2017-09-09 14:54:26'),(3,'Erago','Paris','2017-01-23 15:25:23');

/*Table structure for table `ubt_system_organization` */

DROP TABLE IF EXISTS `ubt_system_organization`;

CREATE TABLE `ubt_system_organization` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Code` varchar(20) DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `Display_Order` int(11) DEFAULT NULL,
  `Parent_ID` int(11) DEFAULT NULL,
  `Icon` varchar(20) DEFAULT NULL,
  `EmpCount` int(11) DEFAULT NULL,
  `Create_By` int(11) DEFAULT NULL,
  `Create_Date` datetime DEFAULT NULL,
  `Update_By` int(11) DEFAULT NULL,
  `Update_Date` datetime DEFAULT NULL,
  `Is_Deleted` varchar(1) DEFAULT 'N',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `ubt_system_organization` */

insert  into `ubt_system_organization`(`ID`,`Code`,`Name`,`Description`,`Display_Order`,`Parent_ID`,`Icon`,`EmpCount`,`Create_By`,`Create_Date`,`Update_By`,`Update_Date`,`Is_Deleted`) values (1,'Company','总公司','公司',1,-1,NULL,1,1,'2016-08-01 13:37:57',1,'2016-08-01 13:37:57','N');

/*Table structure for table `ubt_system_resources` */

DROP TABLE IF EXISTS `ubt_system_resources`;

CREATE TABLE `ubt_system_resources` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `Name` varchar(20) NOT NULL COMMENT '资源名称',
  `Description` varchar(200) DEFAULT NULL COMMENT '资源描述',
  `Url` varchar(100) DEFAULT NULL COMMENT '资源链接',
  `Display_Order` int(11) DEFAULT NULL COMMENT '显示顺序',
  `Parent_ID` int(11) NOT NULL COMMENT '父节点ID',
  `Level` int(11) DEFAULT NULL COMMENT '资源层级',
  `Type` int(11) DEFAULT NULL COMMENT '资源类型',
  `Path` varchar(50) DEFAULT NULL COMMENT '资源路径',
  `Is_Deleted` varchar(1) NOT NULL COMMENT '是否有效',
  `Create_By` int(11) DEFAULT NULL COMMENT '创建人',
  `Create_Date` datetime DEFAULT NULL COMMENT '创建时间',
  `Update_By` int(11) DEFAULT NULL COMMENT '最后更新人',
  `Update_Date` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`ID`,`Name`,`Parent_ID`,`Is_Deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

/*Data for the table `ubt_system_resources` */

insert  into `ubt_system_resources`(`ID`,`Name`,`Description`,`Url`,`Display_Order`,`Parent_ID`,`Level`,`Type`,`Path`,`Is_Deleted`,`Create_By`,`Create_Date`,`Update_By`,`Update_Date`) values (1,'系统管理','系统管理','/System',1,-1,1,1,'1','0',1,'2016-07-20 10:50:03',1,'2016-07-20 10:50:08'),(2,'用户管理','用户管理','/user/manage',1,1,2,1,'1.2','0',1,'2016-07-20 11:02:16',1,'2016-07-28 10:47:06'),(3,'资源管理','资源管理','/resource/manage',3,1,2,1,'1.3','0',1,'2016-07-21 14:41:10',1,'2016-07-28 10:46:53'),(6,'角色管理','角色管理','/role/manage',2,1,2,1,'1.6','0',1,'2016-07-23 16:12:27',1,'2016-07-23 16:12:28'),(7,'列表','角色列表','/role/list',1,6,3,0,'1.6.7','0',1,'2016-07-25 17:26:14',1,'2016-07-25 17:26:16'),(8,'添加','添加角色','/role/add',2,6,3,0,'1.6.8','0',1,'2016-07-26 13:48:00',1,'2016-07-28 15:38:58'),(9,'修改','修改角色','/role/edit',3,6,3,0,'1.6.9','0',1,'2016-07-26 13:48:46',1,'2016-07-28 15:39:03'),(10,'列表','资源列表','/resource/list',1,3,3,0,NULL,'0',1,'2016-07-26 16:33:54',1,'2016-07-28 10:46:16'),(11,'添加','添加资源','/resource/add',1,3,3,0,NULL,'0',1,'2016-07-26 16:39:58',1,'2016-07-28 13:46:22'),(12,'添加','添加用户','/user/add',0,2,3,0,NULL,'0',1,'2016-07-27 13:16:07',1,'2016-07-28 13:46:40'),(13,'授权','授权角色','/role/grant',3,6,3,0,NULL,'0',1,'2016-07-27 13:17:44',1,'2016-07-28 15:40:04'),(14,'修改','修改资源','/resource/edit',2,3,3,0,NULL,'0',1,'2016-07-28 10:45:30',1,'2016-07-28 13:46:47'),(15,'组织管理','组织管理','/org/mange',3,1,2,1,NULL,'0',1,'2016-07-28 13:47:38',1,'2016-07-28 13:47:57'),(16,'修改','修改用户','/user/edit',1,2,3,0,NULL,'0',1,'2016-07-28 14:56:37',1,'2016-07-28 15:29:46'),(20,'删除','删除用户','/user/delete',0,2,3,0,NULL,'0',1,'2016-07-28 15:38:41',1,'2016-07-28 15:38:41'),(21,'授权','授权用户','/user/grant',3,2,3,0,NULL,'0',1,'2016-07-28 15:40:32',1,'2016-07-28 15:40:32'),(22,'获取数据','获取数据','/webserver/manage',4,1,2,1,'1.22','0',1,'2017-01-13 15:05:43',1,'2017-01-13 15:05:46');

/*Table structure for table `ubt_system_role_resource` */

DROP TABLE IF EXISTS `ubt_system_role_resource`;

CREATE TABLE `ubt_system_role_resource` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Res_ID` int(11) DEFAULT NULL COMMENT '资源ID',
  `Role_ID` int(11) DEFAULT NULL COMMENT '角色ID',
  `Create_By` int(11) DEFAULT NULL,
  `Create_Date` datetime DEFAULT NULL,
  `Update_By` int(11) DEFAULT NULL,
  `Update_Date` datetime DEFAULT NULL,
  `Is_Deleted` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Res_ID` (`Res_ID`),
  KEY `Role_ID` (`Role_ID`),
  CONSTRAINT `ubt_system_role_resource_ibfk_1` FOREIGN KEY (`Res_ID`) REFERENCES `ubt_system_resources` (`ID`),
  CONSTRAINT `ubt_system_role_resource_ibfk_2` FOREIGN KEY (`Role_ID`) REFERENCES `ubt_system_roles` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8;

/*Data for the table `ubt_system_role_resource` */

insert  into `ubt_system_role_resource`(`ID`,`Res_ID`,`Role_ID`,`Create_By`,`Create_Date`,`Update_By`,`Update_Date`,`Is_Deleted`) values (40,6,6,1,'2016-07-27 10:44:05',1,'2016-07-28 11:34:51','1'),(41,7,6,1,'2016-07-27 10:44:05',1,'2016-07-28 11:34:51','1'),(42,6,6,1,'2016-07-27 10:44:17',1,'2016-07-28 11:34:51','1'),(43,7,6,1,'2016-07-27 10:44:17',1,'2016-07-28 11:34:51','1'),(44,8,6,1,'2016-07-27 10:44:17',1,'2016-07-28 11:34:51','1'),(45,6,6,1,'2016-07-27 19:24:47',1,'2016-07-28 11:34:51','1'),(46,7,6,1,'2016-07-27 19:24:47',1,'2016-07-28 11:34:51','1'),(47,8,6,1,'2016-07-27 19:24:47',1,'2016-07-28 11:34:51','1'),(48,9,6,1,'2016-07-27 19:24:47',1,'2016-07-28 11:34:51','1'),(49,13,6,1,'2016-07-27 19:24:47',1,'2016-07-28 11:34:51','1'),(50,2,10,1,'2016-07-27 19:25:03',1,'2016-07-28 11:22:57','1'),(51,12,10,1,'2016-07-27 19:25:03',1,'2016-07-28 11:22:57','1'),(52,6,10,1,'2016-07-27 19:25:03',1,'2016-07-28 11:22:57','1'),(53,7,10,1,'2016-07-27 19:25:03',1,'2016-07-28 11:22:57','1'),(54,8,10,1,'2016-07-27 19:25:03',1,'2016-07-28 11:22:57','1'),(55,9,10,1,'2016-07-27 19:25:03',1,'2016-07-28 11:22:57','1'),(56,6,10,1,'2016-07-28 09:54:49',1,'2016-07-28 11:22:57','1'),(57,7,10,1,'2016-07-28 09:54:49',1,'2016-07-28 11:22:57','1'),(58,6,10,1,'2016-07-28 10:04:00',1,'2016-07-28 11:22:57','1'),(59,7,10,1,'2016-07-28 10:04:00',1,'2016-07-28 11:22:57','1'),(60,8,10,1,'2016-07-28 10:04:00',1,'2016-07-28 11:22:57','1'),(61,6,10,1,'2016-07-28 10:06:24',1,'2016-07-28 11:22:57','1'),(62,7,10,1,'2016-07-28 10:06:24',1,'2016-07-28 11:22:57','1'),(63,6,10,1,'2016-07-28 10:07:14',1,'2016-07-28 11:22:57','1'),(64,7,10,1,'2016-07-28 10:07:14',1,'2016-07-28 11:22:57','1'),(65,9,10,1,'2016-07-28 10:07:14',1,'2016-07-28 11:22:57','1'),(66,6,10,1,'2016-07-28 10:10:02',1,'2016-07-28 11:22:57','1'),(67,7,10,1,'2016-07-28 10:10:02',1,'2016-07-28 11:22:57','1'),(68,9,10,1,'2016-07-28 10:10:02',1,'2016-07-28 11:22:57','1'),(69,13,10,1,'2016-07-28 10:10:02',1,'2016-07-28 11:22:57','1'),(70,6,10,1,'2016-07-28 10:13:45',1,'2016-07-28 11:22:57','1'),(71,7,10,1,'2016-07-28 10:13:45',1,'2016-07-28 11:22:57','1'),(72,9,10,1,'2016-07-28 10:13:45',1,'2016-07-28 11:22:57','1'),(73,6,10,1,'2016-07-28 10:14:09',1,'2016-07-28 11:22:57','1'),(74,7,10,1,'2016-07-28 10:14:09',1,'2016-07-28 11:22:57','1'),(75,9,10,1,'2016-07-28 10:14:09',1,'2016-07-28 11:22:57','1'),(76,13,10,1,'2016-07-28 10:14:09',1,'2016-07-28 11:22:57','1'),(77,1,1,1,'2016-07-28 10:38:12',1,'2017-01-14 14:42:02','1'),(78,2,1,1,'2016-07-28 10:38:12',1,'2017-01-14 14:42:02','1'),(79,12,1,1,'2016-07-28 10:38:12',1,'2017-01-14 14:42:02','1'),(80,7,1,1,'2016-07-28 10:38:12',1,'2017-01-14 14:42:02','1'),(81,8,1,1,'2016-07-28 10:38:12',1,'2017-01-14 14:42:02','1'),(82,9,1,1,'2016-07-28 10:38:12',1,'2017-01-14 14:42:02','1'),(83,13,1,1,'2016-07-28 10:38:12',1,'2017-01-14 14:42:02','1'),(84,10,1,1,'2016-07-28 10:38:12',1,'2017-01-14 14:42:02','1'),(85,11,1,1,'2016-07-28 10:38:12',1,'2017-01-14 14:42:02','1'),(86,1,1,1,'2016-07-28 10:45:45',1,'2017-01-14 14:42:02','1'),(87,2,1,1,'2016-07-28 10:45:45',1,'2017-01-14 14:42:02','1'),(88,12,1,1,'2016-07-28 10:45:45',1,'2017-01-14 14:42:02','1'),(89,7,1,1,'2016-07-28 10:45:45',1,'2017-01-14 14:42:02','1'),(90,8,1,1,'2016-07-28 10:45:45',1,'2017-01-14 14:42:02','1'),(91,9,1,1,'2016-07-28 10:45:45',1,'2017-01-14 14:42:02','1'),(92,13,1,1,'2016-07-28 10:45:45',1,'2017-01-14 14:42:02','1'),(93,3,1,1,'2016-07-28 10:45:45',1,'2017-01-14 14:42:02','1'),(94,10,1,1,'2016-07-28 10:45:45',1,'2017-01-14 14:42:02','1'),(95,11,1,1,'2016-07-28 10:45:45',1,'2017-01-14 14:42:02','1'),(96,14,1,1,'2016-07-28 10:45:45',1,'2017-01-14 14:42:02','1'),(97,1,1,1,'2016-07-28 10:54:40',1,'2017-01-14 14:42:02','1'),(98,2,1,1,'2016-07-28 10:54:40',1,'2017-01-14 14:42:02','1'),(99,12,1,1,'2016-07-28 10:54:40',1,'2017-01-14 14:42:02','1'),(100,6,1,1,'2016-07-28 10:54:40',1,'2017-01-14 14:42:02','1'),(101,7,1,1,'2016-07-28 10:54:40',1,'2017-01-14 14:42:02','1'),(102,8,1,1,'2016-07-28 10:54:40',1,'2017-01-14 14:42:02','1'),(103,9,1,1,'2016-07-28 10:54:40',1,'2017-01-14 14:42:02','1'),(104,13,1,1,'2016-07-28 10:54:40',1,'2017-01-14 14:42:02','1'),(105,3,1,1,'2016-07-28 10:54:40',1,'2017-01-14 14:42:02','1'),(106,10,1,1,'2016-07-28 10:54:40',1,'2017-01-14 14:42:02','1'),(107,11,1,1,'2016-07-28 10:54:40',1,'2017-01-14 14:42:02','1'),(108,14,1,1,'2016-07-28 10:54:40',1,'2017-01-14 14:42:02','1'),(109,6,10,1,'2016-07-28 10:54:55',1,'2016-07-28 11:22:57','1'),(110,7,10,1,'2016-07-28 10:54:55',1,'2016-07-28 11:22:57','1'),(111,8,10,1,'2016-07-28 10:54:55',1,'2016-07-28 11:22:57','1'),(112,9,10,1,'2016-07-28 10:54:55',1,'2016-07-28 11:22:57','1'),(113,13,10,1,'2016-07-28 10:54:55',1,'2016-07-28 11:22:57','1'),(114,6,6,1,'2016-07-28 10:55:45',1,'2016-07-28 11:34:51','1'),(115,3,6,1,'2016-07-28 10:55:45',1,'2016-07-28 11:34:51','1'),(116,10,6,1,'2016-07-28 10:55:45',1,'2016-07-28 11:34:51','1'),(117,11,6,1,'2016-07-28 10:55:45',1,'2016-07-28 11:34:51','1'),(118,14,6,1,'2016-07-28 10:55:45',1,'2016-07-28 11:34:51','1'),(119,3,6,1,'2016-07-28 10:57:04',1,'2016-07-28 11:34:51','1'),(120,10,6,1,'2016-07-28 10:57:04',1,'2016-07-28 11:34:51','1'),(121,11,6,1,'2016-07-28 10:57:04',1,'2016-07-28 11:34:51','1'),(122,14,6,1,'2016-07-28 10:57:04',1,'2016-07-28 11:34:51','1'),(123,1,6,1,'2016-07-28 10:57:18',1,'2016-07-28 11:34:51','1'),(124,3,6,1,'2016-07-28 10:57:18',1,'2016-07-28 11:34:51','1'),(125,10,6,1,'2016-07-28 10:57:18',1,'2016-07-28 11:34:51','1'),(126,11,6,1,'2016-07-28 10:57:18',1,'2016-07-28 11:34:51','1'),(127,14,6,1,'2016-07-28 10:57:18',1,'2016-07-28 11:34:51','1'),(128,1,10,1,'2016-07-28 11:22:57',1,'2016-07-28 11:22:57','0'),(129,6,10,1,'2016-07-28 11:22:57',1,'2016-07-28 11:22:57','0'),(130,7,10,1,'2016-07-28 11:22:57',1,'2016-07-28 11:22:57','0'),(131,8,10,1,'2016-07-28 11:22:57',1,'2016-07-28 11:22:57','0'),(132,9,10,1,'2016-07-28 11:22:57',1,'2016-07-28 11:22:57','0'),(133,13,10,1,'2016-07-28 11:22:57',1,'2016-07-28 11:22:57','0'),(134,1,6,13,'2016-07-28 11:28:19',1,'2016-07-28 11:34:51','1'),(135,3,6,13,'2016-07-28 11:28:19',1,'2016-07-28 11:34:51','1'),(136,1,6,1,'2016-07-28 11:28:57',1,'2016-07-28 11:34:51','1'),(137,3,6,1,'2016-07-28 11:28:57',1,'2016-07-28 11:34:51','1'),(138,10,6,1,'2016-07-28 11:28:57',1,'2016-07-28 11:34:51','1'),(139,1,6,1,'2016-07-28 11:34:48',1,'2016-07-28 11:34:51','1'),(140,6,6,1,'2016-07-28 11:34:48',1,'2016-07-28 11:34:51','1'),(141,7,6,1,'2016-07-28 11:34:48',1,'2016-07-28 11:34:51','1'),(142,8,6,1,'2016-07-28 11:34:48',1,'2016-07-28 11:34:51','1'),(143,3,6,1,'2016-07-28 11:34:48',1,'2016-07-28 11:34:51','1'),(144,10,6,1,'2016-07-28 11:34:48',1,'2016-07-28 11:34:51','1'),(145,1,6,1,'2016-07-28 11:34:51',1,'2016-07-28 11:34:51','0'),(146,6,6,1,'2016-07-28 11:34:51',1,'2016-07-28 11:34:51','0'),(147,7,6,1,'2016-07-28 11:34:51',1,'2016-07-28 11:34:51','0'),(148,8,6,1,'2016-07-28 11:34:51',1,'2016-07-28 11:34:51','0'),(149,3,6,1,'2016-07-28 11:34:51',1,'2016-07-28 11:34:51','0'),(150,10,6,1,'2016-07-28 11:34:51',1,'2016-07-28 11:34:51','0'),(151,1,1,1,'2016-07-28 13:48:13',1,'2017-01-14 14:42:02','1'),(152,2,1,1,'2016-07-28 13:48:13',1,'2017-01-14 14:42:02','1'),(153,12,1,1,'2016-07-28 13:48:13',1,'2017-01-14 14:42:02','1'),(154,6,1,1,'2016-07-28 13:48:13',1,'2017-01-14 14:42:02','1'),(155,7,1,1,'2016-07-28 13:48:13',1,'2017-01-14 14:42:02','1'),(156,8,1,1,'2016-07-28 13:48:13',1,'2017-01-14 14:42:02','1'),(157,9,1,1,'2016-07-28 13:48:13',1,'2017-01-14 14:42:02','1'),(158,13,1,1,'2016-07-28 13:48:13',1,'2017-01-14 14:42:02','1'),(159,3,1,1,'2016-07-28 13:48:13',1,'2017-01-14 14:42:02','1'),(160,10,1,1,'2016-07-28 13:48:13',1,'2017-01-14 14:42:02','1'),(161,11,1,1,'2016-07-28 13:48:13',1,'2017-01-14 14:42:02','1'),(162,14,1,1,'2016-07-28 13:48:13',1,'2017-01-14 14:42:02','1'),(163,15,1,1,'2016-07-28 13:48:13',1,'2017-01-14 14:42:02','1'),(164,1,1,1,'2016-07-28 16:09:06',1,'2017-01-14 14:42:02','1'),(165,2,1,1,'2016-07-28 16:09:06',1,'2017-01-14 14:42:02','1'),(166,12,1,1,'2016-07-28 16:09:06',1,'2017-01-14 14:42:02','1'),(167,20,1,1,'2016-07-28 16:09:06',1,'2017-01-14 14:42:02','1'),(168,16,1,1,'2016-07-28 16:09:06',1,'2017-01-14 14:42:02','1'),(169,21,1,1,'2016-07-28 16:09:06',1,'2017-01-14 14:42:02','1'),(170,6,1,1,'2016-07-28 16:09:06',1,'2017-01-14 14:42:02','1'),(171,7,1,1,'2016-07-28 16:09:06',1,'2017-01-14 14:42:02','1'),(172,8,1,1,'2016-07-28 16:09:06',1,'2017-01-14 14:42:02','1'),(173,9,1,1,'2016-07-28 16:09:06',1,'2017-01-14 14:42:02','1'),(174,13,1,1,'2016-07-28 16:09:06',1,'2017-01-14 14:42:02','1'),(175,3,1,1,'2016-07-28 16:09:06',1,'2017-01-14 14:42:02','1'),(176,10,1,1,'2016-07-28 16:09:06',1,'2017-01-14 14:42:02','1'),(177,11,1,1,'2016-07-28 16:09:06',1,'2017-01-14 14:42:02','1'),(178,14,1,1,'2016-07-28 16:09:06',1,'2017-01-14 14:42:02','1'),(179,15,1,1,'2016-07-28 16:09:06',1,'2017-01-14 14:42:02','1'),(180,1,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0'),(181,2,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0'),(182,12,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0'),(183,20,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0'),(184,16,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0'),(185,21,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0'),(186,6,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0'),(187,7,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0'),(188,8,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0'),(189,9,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0'),(190,13,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0'),(191,3,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0'),(192,10,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0'),(193,11,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0'),(194,14,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0'),(195,15,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0'),(196,22,1,1,'2017-01-14 14:42:02',1,'2017-01-14 14:42:02','0');

/*Table structure for table `ubt_system_roles` */

DROP TABLE IF EXISTS `ubt_system_roles`;

CREATE TABLE `ubt_system_roles` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Code` varchar(10) DEFAULT NULL,
  `Name` varchar(20) NOT NULL,
  `Order_No` int(11) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `Create_By` int(11) DEFAULT NULL,
  `Create_Date` datetime DEFAULT NULL,
  `Update_By` int(11) DEFAULT NULL,
  `Update_Date` datetime DEFAULT NULL,
  `Is_Deleted` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `ubt_system_roles` */

insert  into `ubt_system_roles`(`ID`,`Code`,`Name`,`Order_No`,`Description`,`Create_By`,`Create_Date`,`Update_By`,`Update_Date`,`Is_Deleted`) values (1,'admin','超级管理员',1,'超级管理员，拥有全部权限',1,'2016-07-23 15:58:21',1,'2016-07-25 15:48:28','0'),(2,'op1','运维部门1',6,'负责部门1的运维工作',1,'2016-07-25 11:18:12',1,'2016-07-25 11:18:13','0'),(3,'op2','运维部门2',7,'负责部门2的运维工作',1,'2016-07-25 11:18:34',1,'2016-07-25 11:18:34','0'),(4,'financial','财务角色',3,'负责财务部门的工作',1,'2016-07-25 11:20:17',1,'2016-07-25 11:20:19','0'),(5,'market','市场角色',5,'负责市场部门的工作',1,'2016-07-25 11:20:21',1,'2016-07-25 11:20:23','0'),(6,'hr','人事角色',2,'负责人事部门的工作',1,'2016-07-25 11:20:25',1,'2016-07-27 10:44:59','0'),(7,'dev','研发角色',4,'负责研发部门的工作',1,'2016-07-25 11:20:28',1,'2016-07-25 11:20:30','0'),(8,'product','产品角色',NULL,'负责产品部门的工作',1,'2016-07-25 15:30:01',1,'2016-07-27 13:44:57','0'),(10,'office','行政角色',NULL,'负责行政部门的工作',1,'2016-07-25 15:49:24',1,'2016-07-25 15:49:34','0');

/*Table structure for table `ubt_system_user_role` */

DROP TABLE IF EXISTS `ubt_system_user_role`;

CREATE TABLE `ubt_system_user_role` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) DEFAULT NULL COMMENT '用户ID',
  `Role_ID` int(11) DEFAULT NULL COMMENT '角色ID',
  `Create_By` int(11) DEFAULT NULL,
  `Create_Date` datetime DEFAULT NULL,
  `Update_By` int(11) DEFAULT NULL,
  `Update_Date` datetime DEFAULT NULL,
  `Is_Deleted` varchar(1) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

/*Data for the table `ubt_system_user_role` */

insert  into `ubt_system_user_role`(`ID`,`User_ID`,`Role_ID`,`Create_By`,`Create_Date`,`Update_By`,`Update_Date`,`Is_Deleted`) values (1,1,1,1,'2016-07-27 16:39:26',1,'2016-07-28 10:38:20','1'),(2,1,2,1,'2016-07-27 16:40:30',1,'2016-07-28 10:38:20','1'),(3,1,3,1,'2016-07-27 16:40:39',1,'2016-07-28 10:38:20','1'),(4,5,3,1,'2016-07-27 17:05:16',1,'2016-07-28 10:57:30','1'),(5,1,4,1,'2016-07-27 17:20:04',1,'2016-07-28 10:38:20','1'),(6,1,7,1,'2016-07-27 17:20:12',1,'2016-07-28 10:38:20','1'),(7,1,10,1,'2016-07-27 17:20:10',1,'2016-07-28 10:38:20','1'),(8,5,10,1,'2016-07-27 17:20:30',1,'2016-07-28 10:57:30','1'),(9,10,2,1,'2016-07-27 18:24:13',1,'2016-07-27 18:25:19','1'),(10,10,3,1,'2016-07-27 18:24:15',1,'2016-07-27 18:25:19','1'),(11,10,3,1,'2016-07-27 18:25:19',1,'2016-07-27 18:25:19','0'),(12,10,4,1,'2016-07-27 18:25:19',1,'2016-07-27 18:25:19','0'),(13,1,1,1,'2016-07-27 19:37:02',1,'2016-07-28 10:38:20','1'),(14,1,2,1,'2016-07-27 19:37:02',1,'2016-07-28 10:38:20','1'),(15,1,3,1,'2016-07-27 19:37:02',1,'2016-07-28 10:38:20','1'),(16,1,4,1,'2016-07-27 19:37:02',1,'2016-07-28 10:38:20','1'),(17,1,7,1,'2016-07-27 19:37:02',1,'2016-07-28 10:38:20','1'),(18,1,10,1,'2016-07-27 19:37:02',1,'2016-07-28 10:38:20','1'),(19,1,5,1,'2016-07-27 19:37:02',1,'2016-07-28 10:38:20','1'),(20,1,6,1,'2016-07-27 19:37:02',1,'2016-07-28 10:38:20','1'),(21,1,8,1,'2016-07-27 19:37:02',1,'2016-07-28 10:38:20','1'),(22,5,6,1,'2016-07-27 19:38:39',1,'2016-07-28 10:57:30','1'),(23,13,10,1,'2016-07-28 09:56:40',1,'2016-07-28 10:55:03','1'),(24,1,1,1,'2016-07-28 10:38:20',1,'2016-07-28 10:38:20','0'),(25,1,2,1,'2016-07-28 10:38:20',1,'2016-07-28 10:38:20','0'),(26,1,3,1,'2016-07-28 10:38:20',1,'2016-07-28 10:38:20','0'),(27,1,4,1,'2016-07-28 10:38:20',1,'2016-07-28 10:38:20','0'),(28,1,7,1,'2016-07-28 10:38:20',1,'2016-07-28 10:38:20','0'),(29,1,10,1,'2016-07-28 10:38:20',1,'2016-07-28 10:38:20','0'),(30,1,5,1,'2016-07-28 10:38:20',1,'2016-07-28 10:38:20','0'),(31,1,6,1,'2016-07-28 10:38:20',1,'2016-07-28 10:38:20','0'),(32,1,8,1,'2016-07-28 10:38:20',1,'2016-07-28 10:38:20','0'),(33,13,10,1,'2016-07-28 10:55:03',1,'2016-07-28 10:55:03','0'),(34,5,6,1,'2016-07-28 10:55:55',1,'2016-07-28 10:57:30','1'),(35,5,6,1,'2016-07-28 10:57:30',1,'2016-07-28 10:57:30','0');

/*Table structure for table `ubt_system_users` */

DROP TABLE IF EXISTS `ubt_system_users`;

CREATE TABLE `ubt_system_users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `Login_Name` varchar(30) NOT NULL,
  `User_Name` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Gender` varchar(1) DEFAULT NULL,
  `Birth` date DEFAULT NULL,
  `Dept_No` int(11) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Mobile` varchar(11) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `Create_By` int(11) DEFAULT NULL,
  `Create_Date` datetime DEFAULT NULL,
  `Update_By` int(11) DEFAULT NULL,
  `Update_Date` datetime DEFAULT NULL,
  `Is_Deleted` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

/*Data for the table `ubt_system_users` */

insert  into `ubt_system_users`(`ID`,`Login_Name`,`User_Name`,`Password`,`Gender`,`Birth`,`Dept_No`,`Email`,`Mobile`,`Address`,`Create_By`,`Create_Date`,`Update_By`,`Update_Date`,`Is_Deleted`) values (1,'admin','系统管理员','admin','M','1991-01-14',0,'aa@gmail.com','13966201125','广东省深圳市南山区高新南七道',1,'2016-07-20 10:52:15',1,'2016-07-20 16:57:21','0'),(2,'Sales','销售主管','123456','F','1984-02-21',2,'sales@sina.com','17099382771',NULL,1,'2016-07-21 10:27:36',1,'2016-07-21 10:27:38','0'),(5,'HR','人事主管','123456','F','1989-06-30',1,'hr@gmail.com','13655230078',NULL,1,'2016-07-20 17:06:38',1,'2016-07-20 17:06:38','0'),(6,'zhangsan','张三','123456','M','1990-10-21',1,'zs@163.com','18933652201',NULL,1,'2016-07-21 10:23:29',1,'2016-07-21 10:23:26','0'),(7,'Lisi','李四','123456','F','1992-11-10',1,'ls@163.com','15200930092',NULL,1,'2016-07-21 10:24:14',1,'2016-07-21 10:24:17','0'),(8,'wangwu','王五','123456','M','1989-09-21',1,'ww@sohu.com','18300928810',NULL,1,'2016-07-21 10:25:03',1,'2016-07-21 10:25:06','0'),(9,'Support','技术支持','123456','F','1993-02-15',3,'support@qq.com','15109886522',NULL,1,'2016-07-22 16:31:22',1,'2016-07-27 14:40:10','0'),(10,'OP1','秦六合','123456','F','1993-08-03',NULL,NULL,'13789099382',NULL,1,'2016-07-26 14:22:45',1,'2016-07-26 14:24:11','0'),(11,'sale1','销售专员1','123456','F','1994-02-11',NULL,'sales1@sina.com','18966352210',NULL,1,'2016-07-27 14:01:36',1,'2016-07-27 14:02:47','0'),(12,'sale2','销售专员2','123456','F','1990-12-26',NULL,'sales2@gmail.com','17533021156',NULL,1,'2016-07-27 14:16:31',1,'2016-07-27 14:16:44','0'),(13,'off1','行政1','123456','F','1993-04-12',NULL,'off1@sina.com','13400215562',NULL,1,'2016-07-28 09:56:33',1,'2016-07-28 09:56:33','0'),(14,'dev1','研发1','123456','M','1992-08-21',NULL,'dev1@ubt.com','13655201121','深圳市南山区',1,'2016-07-28 17:16:25',1,'2016-07-28 17:16:25','0');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
